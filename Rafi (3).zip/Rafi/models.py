class ThesisProject:
    def __init__(self, title, description, supervisor):
        self.title = title
        self.description = description
        self.supervisor = supervisor