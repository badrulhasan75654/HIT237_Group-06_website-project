from django.shortcuts import render
from .models import ThesisProject

def home(request):
    return render(request, 'home.html')

def project_list(request):
    projects = [
        ThesisProject('Project 1', 'Description of Project 1', 'Supervisor 1'),
        ThesisProject('Project 2', 'Description of Project 2', 'Supervisor 2'),
        ThesisProject('Project 3', 'Description of Project 3', 'Supervisor 3'),
        ThesisProject('Project 4', 'Description of Project 4', 'Supervisor 4'),
        ThesisProject('Project 5', 'Description of Project 5', 'Supervisor 5'),
        ThesisProject('Project 6', 'Description of Project 6', 'Supervisor 6'),
        ThesisProject('Project 7', 'Description of Project 7', 'Supervisor 7'),
    ]
    return render(request, 'project_list.html', {'projects': projects})
